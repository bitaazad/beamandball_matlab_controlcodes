G = tf([0.1785],[1 0 0])
nyquist(G)