

G = tf([0.1785],[1 0 0])
s=tf('s')
Gc = 33+19/s+22*s
sys=series(G,Gc)
sys = (1/(s^2+1))*series(G,Gc)

num=[3.927 5.89 3.391];
den=[1 0 1 0 0 0];
FT = tf(num,den);                                           
syms s t                                                    
snum = poly2sym(num, s)                                     
sden = poly2sym(den, s)                                     
FT_time_domain = ilaplace(snum/sden)

t=0:0.1:100
c=(589*t)/100 - (67*cos(t))/125 - (589*sin(t))/100 + (3391*t.^2)/2000 + 67/125;
plot(t,c)