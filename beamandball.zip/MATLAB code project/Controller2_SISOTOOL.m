G = tf([0.1785],[1 0 0])
s=tf('s')
Gc = 33+19/s+22*s
sys = series(G,Gc)
sisotool(sys)