G = tf([0.1785],[1 0 0])
Gc = tf([50.20 37.65],[1 4.7]) 
series(G,Gc)
rlocus(series(G,Gc))