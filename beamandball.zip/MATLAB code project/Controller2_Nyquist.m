G = tf([0.1785],[1 0 0])
s=tf('s')
Gc = 33+19/s+22*s
series(G,Gc)
feedback(series(G,Gc),1)
nyquist(series(G,Gc))