%*** uncompensated unit feedback
num=[0.1785];
den=[1 0 0];
sys=tf(num,den);
G=feedback(sys,1)
 
%*** compensated unit feedback
numc=[8.96 6.72];
denc=[1 4.7 8.96 6.72];
Gc=tf(numc,denc);

step(G,10)
hold on
step(Gc,10)
